# 阿伟练习
#死循环
while True:
    print('123')

