# 阿伟练习
print(1 > 2)

print(1 < 2)
#在python中不仅仅可以用True和False来表示真假

print(bool(10086))#True
print(bool(0))#False
print(bool(-1))#True

print(bool('hello'))#True
print(bool(' '))#True
print(bool(''))#False

print(bool([12345])) #True
print(bool([]))#False

#在python中，只要是空的都是False，只要有东西就是True

print(bool(None))#False
print(bool([0]))#True

data = [123]
if data:
    print(data[0])
else:
    print('无数据')